//
//  calculator_app_for_pre_schoolTests.swift
//  calculator app for pre schoolTests
//
//  Created by gd13aaf on 20/03/2017.
//  Copyright © 2017 gd13aaf. All rights reserved.
//

import XCTest
@testable import calculator_app_for_pre_school

class calculator_app_for_pre_schoolTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measureBlock {
            // Put the code you want to measure the time of here.
        }
    }
    
}
